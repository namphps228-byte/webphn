<?php get_header(); ?>
<main class="wrap section" id="main">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>">← Về trang chủ</a>
    <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
            <article <?php post_class(); ?>>
                <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
                <?php is_singular() ? the_content() : the_excerpt(); ?>
            </article>
        <?php endwhile; ?>
        <?php the_posts_navigation(); ?>
    <?php else : ?>
        <p>Chưa tìm thấy nội dung.</p>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
