<?php
/**
 * Collect contact requests and make them available to site administrators.
 */
defined( 'ABSPATH' ) || exit;

function webphn_inquiry_services() {
	return array(
		'website'     => 'Website thương hiệu',
		'landingpage' => 'Landing page & đặt lịch',
		'branding'    => 'Nhận diện & trải nghiệm',
		'marketing'   => 'Đồng hành vận hành',
	);
}

add_action( 'init', function () {
	$admin_caps = array_fill_keys(
		array(
			'edit_post', 'read_post', 'delete_post', 'edit_posts',
			'edit_others_posts', 'edit_private_posts', 'edit_published_posts',
			'publish_posts', 'read_private_posts', 'delete_posts',
			'delete_others_posts', 'delete_published_posts', 'delete_private_posts',
		),
		'manage_options'
	);
	$admin_caps['create_posts'] = 'do_not_allow';
	register_post_type( 'webphn_inquiry', array(
		'labels'             => array(
			'name'          => 'Liên hệ webphn',
			'singular_name' => 'Yêu cầu liên hệ',
			'menu_name'     => 'Liên hệ webphn',
			'edit_item'     => 'Chi tiết yêu cầu liên hệ',
			'all_items'     => 'Tất cả liên hệ',
			'not_found'     => 'Chưa có yêu cầu liên hệ.',
		),
		'public'             => false,
		'publicly_queryable' => false,
		'exclude_from_search' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_rest'       => false,
		'show_in_admin_bar'  => false,
		'can_export'         => false,
		'query_var'          => false,
		'rewrite'            => false,
		'supports'           => false,
		'menu_icon'          => 'dashicons-email-alt',
		'capabilities'       => $admin_caps,
		'map_meta_cap'       => false,
	) );
} );

add_action( 'rest_api_init', function () {
	register_rest_route( 'webphn/v1', '/inquiries', array(
		'methods'             => WP_REST_Server::CREATABLE,
		'permission_callback' => '__return_true',
		'callback'            => 'webphn_receive_inquiry',
	) );
} );

function webphn_url_origin( $url ) {
	$parts = wp_parse_url( $url );
	if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return '';
	}
	$scheme = strtolower( $parts['scheme'] );
	$port   = $parts['port'] ?? ( 'https' === $scheme ? 443 : 80 );
	return $scheme . '://' . strtolower( $parts['host'] ) . ':' . $port;
}

function webphn_receive_inquiry( WP_REST_Request $request ) {
	$origin = $request->get_header( 'origin' );
	if ( '1' !== $request->get_header( 'x-app-request' ) || ( $origin && webphn_url_origin( $origin ) !== webphn_url_origin( home_url() ) ) ) {
		return new WP_Error( 'webphn_origin', 'Vui lòng gửi yêu cầu từ form trên website.', array( 'status' => 403 ) );
	}
	if ( strlen( $request->get_body() ) > 20000 ) {
		return new WP_Error( 'webphn_size', 'Nội dung yêu cầu quá dài.', array( 'status' => 413 ) );
	}
	$input = $request->get_json_params();
	if ( ! is_array( $input ) ) {
		return new WP_Error( 'webphn_json', 'Định dạng yêu cầu không hợp lệ.', array( 'status' => 400 ) );
	}
	foreach ( array( 'name', 'phone', 'service', 'message', 'email' ) as $key ) {
		if ( ! isset( $input[ $key ] ) && 'email' === $key ) {
			$input[ $key ] = '';
		}
		if ( ! isset( $input[ $key ] ) || ! is_string( $input[ $key ] ) ) {
			return new WP_Error( 'webphn_fields', 'Vui lòng kiểm tra các trường bắt buộc.', array( 'status' => 400 ) );
		}
	}
	$name    = sanitize_text_field( $input['name'] );
	$phone   = preg_replace( '/[\s.()\-]/', '', trim( $input['phone'] ) );
	$email   = trim( $input['email'] );
	$service = $input['service'];
	$message = sanitize_textarea_field( $input['message'] );
	$valid   = mb_strlen( $name, 'UTF-8' ) >= 2 && mb_strlen( $name, 'UTF-8' ) <= 80
		&& preg_match( '/^(?:0[1-9][0-9]{8}|\+84[1-9][0-9]{8})$/D', $phone )
		&& ( '' === $email || ( strlen( $email ) <= 254 && is_email( $email ) ) )
		&& isset( webphn_inquiry_services()[ $service ] )
		&& mb_strlen( $message, 'UTF-8' ) >= 10 && mb_strlen( $message, 'UTF-8' ) <= 2000;
	if ( ! $valid ) {
		return new WP_Error( 'webphn_invalid', 'Kiểm tra lại thông tin, dịch vụ và mô tả từ 10 đến 2.000 ký tự.', array( 'status' => 400 ) );
	}

	$address = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : 'local';
	$bucket  = 'webphn_form_' . wp_hash( $address );
	$count   = (int) get_transient( $bucket );
	if ( $count >= 5 ) {
		return new WP_Error( 'webphn_rate', 'Bạn đã gửi nhiều yêu cầu. Vui lòng thử lại sau ít phút.', array( 'status' => 429 ) );
	}

	// Store the whole request in one private record, without exposing form details in the API.
	$fields = compact( 'name', 'phone', 'email', 'service', 'message' );
	$id = wp_insert_post( wp_slash( array(
		'post_type'    => 'webphn_inquiry',
		'post_status'  => 'private',
		'post_title'   => $name,
		'post_content' => wp_json_encode( $fields, JSON_UNESCAPED_UNICODE | JSON_HEX_AMP | JSON_HEX_TAG ),
	) ), true );
	if ( is_wp_error( $id ) || ! $id ) {
		return new WP_Error( 'webphn_storage', 'Chưa lưu được lời nhắn. Bạn thử lại nhé.', array( 'status' => 500 ) );
	}
	set_transient( $bucket, $count + 1, 10 * MINUTE_IN_SECONDS );
	return new WP_REST_Response( array( 'id' => $id ), 201 );
}

add_action( 'add_meta_boxes_webphn_inquiry', function () {
	remove_meta_box( 'submitdiv', 'webphn_inquiry', 'side' );
	add_meta_box( 'webphn_inquiry_details', 'Thông tin liên hệ', 'webphn_show_inquiry', 'webphn_inquiry', 'normal', 'high' );
} );

function webphn_show_inquiry( WP_Post $post ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$details  = (array) json_decode( $post->post_content, true );
	$services = webphn_inquiry_services();
	$rows     = array(
		'Mã yêu cầu'    => '#' . $post->ID,
		'Tên'           => $details['name'] ?? $post->post_title,
		'Số điện thoại' => $details['phone'] ?? '',
		'Email'         => ! empty( $details['email'] ) ? $details['email'] : 'Chưa cung cấp',
		'Dịch vụ'       => $services[ $details['service'] ?? '' ] ?? '',
		'Lời nhắn'      => $details['message'] ?? '',
	);
	echo '<table class="widefat striped"><tbody>';
	foreach ( $rows as $label => $value ) {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( $value ) ) . '</td></tr>';
	}
	echo '</tbody></table>';
}
