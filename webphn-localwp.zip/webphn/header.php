<!doctype html>
<html <?php language_attributes(); ?> data-theme="light" data-motion="on">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#fafbf9">
<?php if ( is_front_page() ) : ?>
<meta name="description" content="webphn — thiết kế website, landing page và trải nghiệm số có dấu ấn riêng.">
<?php endif; ?>
<?php if ( ! has_site_icon() ) : ?>
<link rel="icon" href="<?php echo esc_url( get_theme_file_uri( 'favicon.svg' ) ); ?>" type="image/svg+xml">
<?php endif; ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
