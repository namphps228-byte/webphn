<?php
defined( 'ABSPATH' ) || exit;

require_once get_template_directory() . '/inc/inquiries.php';

add_action( 'after_setup_theme', function () {
    add_theme_support( 'title-tag' );
    add_theme_support( 'html5', array( 'style', 'script', 'search-form', 'gallery', 'caption' ) );
    load_theme_textdomain( 'webphn', get_template_directory() . '/languages' );
} );

add_action( 'wp_enqueue_scripts', function () {
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'webphn', get_stylesheet_uri(), array(), $version );
    if ( ! is_front_page() ) {
        return;
    }

    wp_enqueue_style( 'webphn-motion', get_theme_file_uri( 'motion.css' ), array( 'webphn' ), $version );
    wp_enqueue_style( 'webphn-hero', get_theme_file_uri( 'fluid-background-fix.css' ), array( 'webphn-motion' ), $version );
    wp_enqueue_script( 'webphn-data', get_theme_file_uri( 'data.js' ), array(), $version, true );
    wp_add_inline_script( 'webphn-data', 'window.webphnTheme = ' . wp_json_encode(
        array(
            'baseUrl'    => trailingslashit( get_template_directory_uri() ),
            'inquiryUrl' => rest_url( 'webphn/v1/inquiries' ),
        ),
        JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
    ) . ';', 'before' );

    wp_enqueue_script( 'webphn-app', get_theme_file_uri( 'app.js' ), array( 'webphn-data' ), $version, true );
    wp_enqueue_script( 'webphn-fluid', get_theme_file_uri( 'fluid-brand.js' ), array( 'webphn-app' ), $version, true );
    wp_enqueue_script( 'webphn-motion', get_theme_file_uri( 'motion.js' ), array( 'webphn-app' ), $version, true );
} );
